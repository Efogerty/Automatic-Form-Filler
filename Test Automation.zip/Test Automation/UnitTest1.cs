using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;

namespace Test_Automation
{
[TestFixture]
public class Tests
{  
        IWebDriver driver;
        [OneTimeSetUp]
        public void Setup()
        {
            driver = new ChromeDriver();
        }
        //format phone number with () - because it doesn't do anything to the test case, but really helps in verification
        [TestCase("Evan","Fogerty","efogerty11@icloud.com","(803) 504-1305","South Carolina","Columbia")]
        [TestCase("Charlie","Chaplin","dummy@aol.com","(703) 687-1424","Ohio","Columbus")]
        [TestCase("Gray","Jones","evendumberdummy@yahoo.com","(123) 867-5309","Wyoming","Cheyenne")]
        //general test format for any input
        public void AutomaticTest(string first, string last, string email, string phone, string state, string city)
        {   
            //start the google chrome window
            driver.Url = "https://www.cognitoforms.com/CognitoForms/testautomation?v2";
            
            //give the window time to load before commands go in
            System.Threading.Thread.Sleep(4000);
            //find the text boxes on screen utilizing Xpath
            driver.FindElement(By.XPath("//*[@id=\"cog-input-auto-0\"]")).SendKeys(first); 
            driver.FindElement(By.XPath("//*[@id=\"cog-input-auto-1\"]")).SendKeys(last);
            driver.FindElement(By.XPath("//*[@id=\"cog-1\"]")).SendKeys(email);
            driver.FindElement(By.XPath("//*[@id=\"cog-3\"]")).SendKeys(state);
            //give a small rest so the dialogue box registers our changes. (This had issues in testing)
            System.Threading.Thread.Sleep(500);
            //I went out of order because the dropdown menu for city sometimes had trouble accepting values typed into its box as the last element
            driver.FindElement(By.XPath("//*[@id=\"cog-4\"]")).SendKeys(city);
            System.Threading.Thread.Sleep(500);
            driver.FindElement(By.XPath("//*[@id=\"cog-2\"]")).SendKeys(phone);
            System.Threading.Thread.Sleep(1000);
            driver.FindElement(By.XPath("/html/body/div[1]/div/div/div/div/div[4]/button")).Click();
            System.Threading.Thread.Sleep(4000);
            if(Equals(driver.FindElement(By.XPath("/html/body/div[1]/div/div/div/div[2]/div[1]/fieldset/div[1]/div")).GetAttribute("innerHTML"),first+" "+last)&&Equals(driver.FindElement(By.XPath("/html/body/div[1]/div/div/div/div[2]/div[2]/div[1]/div[1]")).GetAttribute("innerHTML"),email)&&Equals(driver.FindElement(By.XPath("/html/body/div[1]/div/div/div/div[2]/div[2]/div[2]/div[1]")).GetAttribute("innerHTML"),phone)&&Equals(driver.FindElement(By.XPath("/html/body/div[1]/div/div/div/div[2]/div[3]/div[1]/div[1]/div")).GetAttribute("innerHTML"),state)&&Equals(driver.FindElement(By.XPath("/html/body/div[1]/div/div/div/div[2]/div[3]/div[2]/div[1]/div/div")).GetAttribute("innerHTML"),city)){
                Assert.Pass();
            }else{
                Assert.Fail();
            }
        }

        [OneTimeTearDown]
        public void end()
        {
            driver.Close();
        }
    }
}